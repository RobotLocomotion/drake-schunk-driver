mc.move( 10, 100 ); -- Move to 10mm, speed=100mm/s, wait, until target position was reached.
mc.move( 100, 10, 0 );  -- Move to 100mm, speed=10mm/s, 0=return immediately
sleep( 2000 );
mc.stop();  -- Stop axis
mc.force( 0 );

