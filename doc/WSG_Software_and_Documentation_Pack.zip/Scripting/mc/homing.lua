mc.homing();  -- homes in the default direction
sleep( 500 );
mc.homing( true ); -- homes towards the positive end stop
sleep( 500 );
mc.homing( false ); -- homes towards the negative end stop
