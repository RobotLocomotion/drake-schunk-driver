t = {};
len = 200;    -- Length of the trajectory is 200 points
-- Move to start position:
mc.move( 10, 50 );
-- Calculate trajectory points:
pos = mc.position();
for i=1,len do
    t[i] = pos + ( math.sin(( i - 1 ) * math.pi / len )^2 * 80 );
end;
-- Execute trajectory:
error_code, cnt = mc.trajectory( t );
if error_code ~= 0 then
    -- An error occurred:
    printf( "Error while executing: %s. %d points processed.\n", error2str( error_code ), cnt );
else
    -- No error, wait until movement finished:
    while mc.busy() do
        sleep( 50 );
      end;
    printf( "Trajectory executed successfully\n" );
end;

