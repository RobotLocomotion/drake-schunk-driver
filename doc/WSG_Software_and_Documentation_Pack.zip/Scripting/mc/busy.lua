mc.move( 10, 100 );
mc.move( 100, 10, 0 );  -- Move to 100mm, speed=10mm/s, 0=return immediately
while mc.busy() do
    printf( "Current position: %.2f mm\n", mc.position() );
    sleep( 300 );
end;
printf( "Done, current position: %.2f mm\n", mc.position() );
