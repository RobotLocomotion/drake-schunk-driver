mc.move( 10, 50 );     -- Move to 10mm, speed=50mm/s, wait until finished
mc.move( 50 );         -- Move to 50mm, speed is still 50mm/s, wait until finished
mc.move( 100, 10, 0 ); -- Move to 100mm, speed=10mm/s, Flags: not set
while mc.busy() do
    printf( "Current opening width: %.2f mm\n", mc.position() );
    sleep( 300 );
end;
printf( "Done, opening width: %.2f mm\n", mc.position() );

