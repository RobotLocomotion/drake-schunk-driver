cmd.register( 0xBB );    -- Register ID BBh
cmd.register( 0xBC );    -- Register ID BCh
cmd.register( 0xBD );    -- Register ID BDh
while cmd.online() do
    if cmd.available() > 0 then
        id, payload = cmd.read();
        printf( "Data packet received: ID=%d, payload length=%d\n", id, #payload );
    end;
end;
