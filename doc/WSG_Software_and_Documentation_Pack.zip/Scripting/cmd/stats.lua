stats = cmd.stats();
printf( "Command statistics:\n" );
printf( "\tReceived Packets: %d\n", stats.rx_count );
printf( "\tRx checksum errors: %d\n", stats.checksum_errs );
printf( "\tRx length errors: %d\n", stats.length_errs );
printf( "\tRx timeout errors: %d\n", stats.timeout_errs );
printf( "\tRx unknown IDs: %d\n", stats.unknown_id_errs );
printf( "\tSent packets: %d\n", stats.tx_count );

