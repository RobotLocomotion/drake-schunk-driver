if cmd.online() then
    printf( "Currently online!\n" );
    -- Send a message:
    cmd.register( 0xBB );
    cmd.send( 0xBB, "This is a test!" );
else
    printf( "offline\n" );
end;