id = 0xBB;
cmd.register( id );            -- Register ID BBh
cmd.send( id, "This is a test!" );   -- Send a message to the connected host via this Id
cmd.unregister( id );            -- Un-register ID BBh
cmd.send( id, "I will produce an error!" );   -- This will produce an error!
