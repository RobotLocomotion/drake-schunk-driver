-- Movement sequence:

local limits = gripper.limits()
local SLOW_ACC = 0.04
local FAST_ACC = 0.80
local FORCE = 0.40;

seq = {
  { speed= 2.00 * limits.min_speed, pos= limits.stroke - 1.00, acc= FAST_ACC * limits.max_acc, delay=  500 },
  { speed= 0.10 * limits.max_speed, pos= 0.80 * limits.stroke, acc= FAST_ACC * limits.max_acc, delay=  100 },
  { speed= 0.25 * limits.max_speed, pos= 0.55 * limits.stroke, acc= FAST_ACC * limits.max_acc, delay=  100 },
  { speed= 0.35 * limits.max_speed, pos= 0.30 * limits.stroke, acc= FAST_ACC * limits.max_acc, delay=  100 },
  { speed= 0.50 * limits.max_speed, pos= 0.05 * limits.stroke, acc= FAST_ACC * limits.max_acc, delay= 1000 },
  { speed= 0.70 * limits.max_speed, pos= limits.stroke - 1.00, acc= FAST_ACC * limits.max_acc, delay=  500 },
  { speed= 1.00 * limits.max_speed, pos= 0.80 * limits.stroke, acc= FAST_ACC * limits.max_acc, delay=  100 },
  { speed= 1.00 * limits.max_speed, pos= 0.55 * limits.stroke, acc= FAST_ACC * limits.max_acc, delay=  100 },
  { speed= 1.00 * limits.max_speed, pos= 0.30 * limits.stroke, acc= FAST_ACC * limits.max_acc, delay=  100 },
  { speed= 1.00 * limits.max_speed, pos= 0.05 * limits.stroke, acc= FAST_ACC * limits.max_acc, delay= 1000 },
  { speed= 1.00 * limits.max_speed, pos= limits.stroke - 1.00, acc= SLOW_ACC * limits.max_acc, delay=  500 },
  { speed= 1.00 * limits.max_speed, pos= 0.05 * limits.stroke, acc= SLOW_ACC * limits.max_acc, delay=  500 },
  { speed= 1.00 * limits.max_speed, pos= limits.stroke - 1.00, acc= FAST_ACC * limits.max_acc, delay=  500 },
  { speed= 1.00 * limits.max_speed, pos= 0.05 * limits.stroke, acc= FAST_ACC * limits.max_acc, delay=  500 },
};


-------------------------
--- MAIN DEMO PROGRAM ---
-------------------------

-- Do homing:
mc.homing(1);

-- Set force:
mc.force( FORCE * limits.nominal_force );

-- Set initial acceleration:
current_acc = SLOW_ACC * limits.max_acc;
mc.acceleration( current_acc );

-- Looping through the sequence:
while ( true ) do

  for i=1,#seq do

    -- Set acceleration:
    if ( current_acc ~= seq[i].acc ) then
      current_acc = seq[i].acc;
      mc.acceleration( current_acc );
    end;

    -- Wait for last movement to be finished:
    while ( mc.busy() ) do
      sleep( 10 );
    end;
        
    -- Goto new position:
    mc.move( seq[i].pos, seq[i].speed );

    -- Sleep, if required:
  if ( seq[i].delay > 0 ) then
      sleep( seq[i].delay );
    end;
  end;
end;