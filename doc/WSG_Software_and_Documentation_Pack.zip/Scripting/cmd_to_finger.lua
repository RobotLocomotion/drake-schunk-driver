-- This example implements a custom command (ID=0xBB) to receive data that is 
-- transferred to a finger as raw data using a UART connection with 115200 bit/s:

index = 1; -- Finger to be used

cmd.register( 0xBB );    -- Register command with ID=BBh
finger.interface( index, "uart", 115200 ); -- Open the finger interface in UART mode with 115200 bit/s

if finger.type( index ) == "generic" then
	while true do
		if cmd.online() then
			id, payload = cmd.read(); -- Wait, until a command was received
			if #payload > 0 then
				finger.write( index, payload );  -- Send the complete payload to the finger
			end;
			cmd.send( id, etob( E_SUCCESS )); -- Send E_SUCCESS as return value
		else
			-- Command Interface is offline...
			sleep( 200 );
		end;
	end;
else
	printf( "This example will only work with a generic finger\n" );
end;
		

