-- Constants:
OPEN_POSITION = 70; -- Open width in mm
CLOSE_POSITION = 10; -- Close width in mm
SPEED = 300; -- Finger movement speed

state = 0;
mc.homing();  -- Homes the gripper (not necesssary, if already homed)
mc.force( 50 );  -- Set a force limit of 50 N (the FMF sensor finger is not used in this example!)

while ( true ) do
    
    -- get IO-State (here, IN0 is used):
    last_state = state;
    state = gpio.pin(0);
    
	-- detect a state change:
    if ( state ~= last_state ) then
        if ( state == 1 ) then
            
            -- Close Fingers:
            mc.move( CLOSE_POSITION, SPEED );
            gpio.set( 1 );  -- Set OUT1
        else
            -- Open Fingers:
            mc.move( OPEN_POSITION, SPEED );
            gpio.clear( 1 );  -- Clear OUT1
        end;
    end;
end;
        
